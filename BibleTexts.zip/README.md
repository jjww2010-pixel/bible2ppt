# 사용자 제공 성경 본문 변환본

사용자가 업로드한 개역개정 nkrv_bible.txt, 현대인의성경.txt, 쉬운성경.txt를 Bible2PPT용 로컬 JSON으로 변환한 파일입니다.
현대인의 성경·쉬운성경 입력은 CP949 인코딩의 31,102줄입니다. 빈 줄도 절 위치로 유지해 66권·1,189장·31,102개 절 위치에 대응시켰습니다. 개역개정 입력은 권·장·절 번호가 붙은 UTF-8 파일의 31,325줄이며, 번호 없이 이어진 45줄을 같은 절의 본문에 연결했습니다.
표준 장·절 배열, 66권의 시작 위치, 현대인의 성경 내 절 참조 표기, 요일 4:8과 마지막 절을 대조했습니다.
별도 공식 판본과 모든 문장의 정확성·완전성을 대조한 결과는 아닙니다. 현대인의 성경 창22:23의 자기 참조는 아래와 같이 수정했습니다.

[세 번역본 변환 ZIP 다운로드](https://github.com/jjww2010-pixel/bible2ppt/raw/refs/heads/local-bible-files/BibleTexts.zip)

[개역개정 JSON](https://github.com/jjww2010-pixel/bible2ppt/raw/refs/heads/local-bible-files/Bibles/krv.json)

[쉬운성경 JSON](https://github.com/jjww2010-pixel/bible2ppt/raw/refs/heads/local-bible-files/Bibles/easy.json)

[현대인의 성경 JSON](https://github.com/jjww2010-pixel/bible2ppt/raw/refs/heads/local-bible-files/Bibles/modern.json)

비공개 저장소에 접근할 수 있는 GitHub 계정으로 로그인해 다운로드하세요.
파일 페이지에서 **Download raw file**을 눌러 받을 수도 있습니다.

**이번 수정 상태:** 현대인의 성경 창22:23의 참조 오류와 쉬운성경 공란 7개를 모두 수정했습니다. 쉬운성경은 갓피아의 현재 읽기 화면에서 같은 번역과 앞뒤 절의 일치를 확인한 뒤 보충했습니다. `Audit/source-repair-status.json`에 출처와 확인 결과가 있습니다.

## 적용 방법

[실행 파일·세 번역본 통합 ZIP](https://github.com/jjww2010-pixel/bible2ppt/raw/refs/heads/windows-download/Bible2PPT-v2.2-all-bibles-win-x64.zip)을 사용하면 압축 해제 후 EXE를 실행하는 것만으로 세 번역을 사용할 수 있습니다. 파일 가져오기나 기존 본문 복사가 필요하지 않습니다.

아래 방법은 기존 EXE에서 본문 파일만 갱신하는 경우입니다.

JSON 사용을 권장합니다. JSON에는 원본 대조용 정보도 들어 있으며 선행·후행 공백을 포함한 본문을 보존합니다.

기존 개역개정과 동일한 가져오기 방식입니다. 최신 EXE에서 각 번역을 선택한 후 파일을 한 번씩 가져옵니다. 이미 가져온 경우에도 새 파일을 가져오면 해당 번역만 교체됩니다.

1. ZIP을 압축 해제합니다.
2. 최신 Bible2PPT에서 설정 화면의 **개역개정**을 선택하고 **성경 본문 가져오기**로 `Bibles/krv.json`을 가져옵니다.
3. **쉬운성경**을 선택하고 `Bibles/easy.json`을 가져옵니다.
4. **현대인의 성경**을 선택하고 `Bibles/modern.json`을 가져옵니다.
5. 제작 화면에서 사용할 번역을 선택합니다. 한 번역만 제작하려면 다른 번역을 제작 대상 목록에서 제거합니다.

또는 프로그램을 닫은 상태에서 ZIP의 `Bibles/krv.json`, `Bibles/easy.json`, `Bibles/modern.json`을 실행 파일 옆 `Bibles` 폴더에 복사할 수 있습니다. EXE를 새로 빌드할 필요는 없습니다.

`TXT` 폴더의 번호가 붙은 TXT도 가져올 수 있습니다. 이 형식은 가져오기 과정에서 본문 앞쪽의 공백이 정리될 수 있습니다.
`Audit` 폴더의 TSV는 원문 대조용이며 가져오기 파일이 아닙니다.

## 원본에서 확인한 사항

- 개역개정의 번호 없는 본문 45줄을 앞의 해당 절에 연결했습니다. 원본에 빠진 **행24:7**은 갓피아 개역개정(4판)에서 `(없음)` 표기임을 확인해 그대로 추가했습니다. [행24장 출처](https://www.godpia.com/read/reading.asp?ver=gae&vol=act&chap=24). 임의의 본문을 만들지 않았으며 모든 원본 줄을 대조 정보에서 재구성할 수 있습니다.

- 쉬운성경 원본의 7개 공란 **삿20:22–23, 삼하4:6–7, 왕상8:41–42, 렘16:2**를 보충했습니다. 갓피아에서는 앞의 세 묶음을 각각 두 절을 합친 본문으로 제공합니다. 변환본도 같은 절 범위를 사용하며, 어느 절을 조회해도 실제 본문을 반환합니다. 렘16:2는 단독 절 본문을 보충했습니다. 기존 누락 안내는 제거했습니다.
  [사사기 20장](https://www.godpia.com/read/reading.asp?ver=easy&vol=jdg&chap=20), [사무엘하 4장](https://www.godpia.com/read/reading.asp?ver=easy&vol=2sa&chap=4), [열왕기상 8장](https://www.godpia.com/read/reading.asp?ver=easy&vol=1ki&chap=8), [예레미야 16장](https://www.godpia.com/read/reading.asp?ver=easy&vol=jer&chap=16).
- 현대인의 성경의 연속된 `N절과 같음` 730개(수정한 자기 참조 1개 포함)를 통합 절 범위로 표시합니다. 예를 들어 6절과 7절이 같은 본문이면 `6–7절`로 한 번만 저장하고, 7절 요청도 같은 본문을 반환합니다.
- 연속되지 않은 참조 3개(레20:4 → 2절, 삼하3:36 → 34절, 대하9:16 → 14절)는 원본이 가리키는 본문에 연결했습니다.
- 현대인의 성경 **창22:23**의 잘못된 자기 참조를 수정했습니다. 앞의 22절에 브두엘·리브가 관련 본문이 이미 포함되어 있어 **창22:22–23** 범위로 통합했습니다. 23절 조회도 실제 본문을 반환하며, 잘못된 원본 표기는 대조 정보에만 보존합니다.
- 원문의 `(없음)` 표기, 소제목, 따옴표, 맞춤법·오탈자는 임의로 고치지 않았습니다.

## 검사와 원문 보존

`conversion-report.json`에 원본 SHA-256, 권별 시작 줄, 누락 위치와 참조 경고가 있습니다.
JSON의 `sourceLine`, `originalText`, `sourceMarkers` 정보를 이용해 **현대인의 성경·쉬운성경 원본의 모든 줄을 정확히 재구성**하고 문자별 일치를 확인했습니다.
현대인의 성경은 30,372개 본문 항목이 31,102개 절 위치를 포함하며, 쉬운성경은 복원한 통합 절 3개를 포함해 31,099개 항목이며, 31,102개 절 위치를 모두 포함합니다. 개역개정은 31,089개 본문 항목이 31,102개 절 위치를 포함하며, `Audit/개역개정_변환대조.json`과 JSON의 원본 줄 정보로 원본 31,325줄을 정확히 재구성할 수 있습니다. 현재 미복원 공란은 없습니다.

`Validation` 폴더에는 현재 프로그램의 C# 본문 조회 코드로 JSON·TXT 각각의 모든 절 요청을 검사한 결과가 있습니다.
이 검사는 파일 조회·선택과 숫자 대응을 확인하며, 전체 원문을 별도 공식 판본과 대조하는 검사는 아닙니다. 보충한 7개 절은 갓피아의 쉬운성경 표시와 절 범위를 확인했고, 앞뒤 절이 업로드한 번역과 일치하는지 공백·따옴표·소제목 표기를 정규화해 대조했습니다.
실제 PowerPoint 슬라이드 렌더링은 이 검사에 포함하지 않습니다.

실제 Windows 검사 결과:

[Windows 실행 검사](https://github.com/jjww2010-pixel/bible2ppt/actions/runs/38299983580)에서 x64·x86 배포 EXE로 세 번역본의 JSON·TXT 각각 모든 절 조회가 통과했고, EXE 옆에 세 본문 파일을 둔 상태에서 실제 메인 화면의 초기 로딩과 번역 선택을 확인했습니다.
`Validation/Windows-x64`, `Validation/Windows-x86`에 각 파일의 SHA-256과 검사 결과가 있습니다.
배포 JSON·TXT는 Windows 검사 당시의 CRLF 줄바꿈으로 저장하여 검사한 파일과 SHA-256이 정확히 일치합니다. 원래 본문 문자는 보존하고, 원본 공란과 잘못된 참조만 위에 명시한 방식으로 수정했습니다.

누락분 출처 확인: [갓피아 현재 읽기 화면 검사](https://github.com/jjww2010-pixel/bible2ppt/actions/runs/38293477627). 쉬운성경 번역명, 요청한 권·장·절 속성, 본문 존재와 통합 절 범위를 확인했습니다.
